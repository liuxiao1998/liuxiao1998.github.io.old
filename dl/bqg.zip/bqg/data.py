#coding:utf8
import urllib
import urllib2
import re,random,threading

def FindPat(pat,source):
    rr=re.compile(pat)
    namelist=re.findall(rr,source)
    return namelist

def GetPage(url,data,ip_pool,agents_pool):
    if(ip_pool!=[] and random.randint(0,1)!=0):
        proxy={'http':'%s'%random.choice(ip_pool)}
        proxy_support = urllib2.ProxyHandler(proxy)
        opener = urllib2.build_opener(proxy_support)
        urllib2.install_opener(opener)
    headers = {'User-Agent': '%s'%random.choice(agents_pool)}
    req = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(req)
    page = response.read()
    return page

class TimeException(Exception):
    pass

def GetPage_LimitedTime(timeout,func,url,data,ip_pool,agents_pool):
    class functhread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result=None
        def run(self):
            self.result=func(url,data,ip_pool,agents_pool)
        def _stop(self):
            if(self.isAlive()):
                threading.Thread._Thread__stop(self)
    t1=functhread()
    t1.start()
    t1.join(timeout)
    if(t1.isAlive()):
        t1._stop()
        raise TimeException
    else:
        return t1.result

def DownLoad(url,data,path,sig):
    headers = {
        'Accept':'*/*',
        'Accept-Encoding':'gzip, deflate, br',
        'Accept-Language':'zh-CN,zh;q=0.8',
        'Connection':'keep-alive',
        'Host':'cn-jsnj8-cmcc.acgvideo.com',
        'Origin':'https://www.bilibili.com',
        'Referer':'https://www.bilibili.com/video/av11841947/?from=search&seid=8467782830492741655',
        'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'
    }
    req = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(req)
    page = response.read()
    with open(path,sig) as file:
        file.write(page)

def DownLoad_Proxy(url,data,path,sig):
    proxy={'http':'127.0.0.1:8087'}
    proxy_support = urllib2.ProxyHandler(proxy)
    opener = urllib2.build_opener(proxy_support)
    urllib2.install_opener(opener)
    headers = {
        'User-Agent': 'Mozilla/5.0'
    }
    req = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(req)
    page = response.read()
    with open(path,sig) as file:
        file.write(page)
